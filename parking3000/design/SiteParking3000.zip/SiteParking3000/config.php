<?php
global $bdd = new PDO ("mysql:host=localhost;dbname=parking3000","root","")
    ?>