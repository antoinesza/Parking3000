
    <header>
         <a href="accueil2View.php">Accueil</a>
         <a href="loginView.php">Login</a> 
         <a href="insView.php">Inscription</a> 
         <a href="adminView.php">Admin</a> <br/>
    </header>
