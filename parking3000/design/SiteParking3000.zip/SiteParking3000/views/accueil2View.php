<?php
        require "headerView.php";
    
?>

<p>BIENVENUE SUR PARKING 3000</p>

<?php

        require "footerView.php"; 
?>

