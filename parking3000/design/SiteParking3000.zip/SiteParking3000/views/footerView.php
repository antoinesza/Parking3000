<footer>
    <a href="accueilView.php">Accueil</a>
    <a href="loginView.php">Login</a> 
    <a href="insView.php">Inscription</a> 
    <a href="adminView.php">Admin</a> <br/>
    copyright Parking 3000
</footer>