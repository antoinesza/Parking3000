<?php
    require "/models/accueilModel.php";
        
        

    require "/views/accueilView.php";
?>        