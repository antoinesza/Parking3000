<html>

  <head>
     <title></title>
  </head>

  <body>
      <header>
         <a href="views/accueil2View.php">Accueil</a>
         <a href="views/loginView.php">Login</a> 
         <a href="views/insView.php">Inscription</a> 
         <a href="views/adminView.php">Admin</a>
    </header>
      
        <?php 
            
            echo $content;
 
        ?>
      
      <footer>
          <a href="views/accueil2View.php">Accueil</a>
          <a href="views/loginView.php">Login</a> 
          <a href="views/insView.php">Inscription</a> 
          <a href="views/adminView.php">Admin</a> <br/>
          copyright Parking 3000
      </footer>
    
    </body>
<html>	